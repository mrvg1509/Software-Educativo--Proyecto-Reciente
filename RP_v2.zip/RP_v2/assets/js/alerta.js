
function funcionAlerta(){
Swal.fire({
  position: 'top-end',
  icon: 'success',
  title: 'Actualizado',
  showConfirmButton: false,
  timer: 3500
})
}