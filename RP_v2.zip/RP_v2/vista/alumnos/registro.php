
<?php
  require_once "../config/conexion4.php";

	$dnia = $_POST['dnia'];
	$nombrea = $_POST['nombrea'];
	$apellidoa = $_POST['apellidoa'];
	$codpad = $_POST['codpad'];
	$fecha_naci = $_POST['fecha_naci'];
	$genero = $_POST['genero'];
	$grupo_san = $_POST['grupo_san'];
	$direccion = $_POST['direccion'];
	$pais = $_POST['pais'];
	$codclase  = $_POST['codclase'];
	$codsec  = $_POST['codsec'];
	$codgra  = $_POST['codgra'];
	
	$foto = $_FILES['foto']['name'];
	
	
	$usualu = $_POST['usualu'];
	
	$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
	$role = $_POST['role'];
	
	$fechare=date('Y-m-d');	
	$estado = $_POST['estado'];
	

// Cargando el fichero en la carpeta "subidas"		
if( $dnia!=null||  $nombrea!=null || $apellidoa!=null || $codpad!=null || $fecha_naci!=null || $genero!=null || $grupo_san!=null || $direccion!=null || $pais!=null ||  $codclase!=null ||  $codsec!=null ||  $codgra!=null ||  $foto!=null || $usualu!=null || $password!=null || $role!=null || $fechare!=null || $estado!=null){


$sql = "INSERT INTO alumnos(dnia, nombrea,apellidoa,codpad,fecha_naci,genero,grupo_san,direccion,pais,codclase,codsec,codgra,foto,usualu,password,role,fechare,estado)

VALUES ('$dnia','$nombrea','$apellidoa','$codpad','$fecha_naci','$genero','$grupo_san','$direccion','$pais','$codclase','$codsec','$codgra','$foto','$usualu','$password' ,'$role','$fechare','$estado')";
		
   

	
	$query = $con->prepare( $sql );
	if ($query == false) {
	 print_r($con->errorInfo());
	 die ('Erreur prepare');
	}
	$sth = $query->execute();
	if ($sth == false) {
	 print_r($query->errorInfo());
	 die ('Erreur execute');
	}

}
header('Location: ../../folder/alumnos.php');



   ?>
   <?php
   require_once "../config/conexion4.php";
  
   $foto = $_FILES['foto'];
 
  

// Cargando el fichero en la carpeta "subidas"

move_uploaded_file($foto['tmp_name'], "../../assets/images/imagenes/".$foto['name']);


		?>		
   
  
   