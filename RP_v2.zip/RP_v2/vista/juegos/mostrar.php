<?php
		require_once('../config/DBconect.php');


		$sql = "SELECT id,title,hini,hfinal,start, end, color FROM events";

		$req = $db->prepare($sql);
		$req->execute();

		$events = $req->fetchAll();

		?>
<!DOCTYPE html>
<html lang="es">
<head>
    <title>Panel administrativo</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" sizes="96x96" href="../../assets/images/icono.svg">
    <script src="../../assets/js/sweet-alert.min.js"></script>
    <link rel="stylesheet" href="../../assets/css/sweet-alert.css">
    <link rel="stylesheet" href="../../assets/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="../../assets/css/normalize.css">
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/jquery.mCustomScrollbar.css">
	
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	
	
    
    <script src="../../assets/js/modernizr.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../../assets/js/main.js"></script>
	<link href='../../assets/css/fullcalendar.css' rel='stylesheet' />
	<link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
	<link rel="stylesheet" href="../../assets/css/hora.css">
	<link rel="stylesheet" href="../../assets/css/horaf.css">
	<style>
	 .loading  {
		 position: fixed;
		 left: 0px;
		 top: 0px;
		 width: 100%;
		 height: 100%;
		 z-index: 9999;
		 background: url('../../assets/images/Loading_2.gif') 50% 50% no-repeat rgb(249,249,249);
		opacity: .8; }
	</style>
	
	
	
</head>
<body onload="startTime()">
<div class="loading"></div>
<?php
				session_start();

				if(!isset($_SESSION['admin_login']))	
				{
					header("location: ../vista/login.php");  
				}

				if(isset($_SESSION['personal_login']))	
				{
					header("location: ../vista/docente/docente_portada.php");	
				}

				if(isset($_SESSION['usuarios_login']))	
				{
					header("location: ../vista/estudiante/estudiante_portada.php");
				}
				
				if(isset($_SESSION['admin_login']))
				{
				?>
				
						 
			<style>
@import url(https://fonts.googleapis.com/css?family=Roboto+Condensed:300,400);

.font-roboto {
  font-family: 'roboto condensed';
}

* {
  box-sizing: border-box;
}

body {
  .font-roboto();
}

.modal {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: hidden;
}

.modal-dialog {
  position: fixed;
  margin: 0;
  width: 100%;
  height: 100%;
  padding: 0;
}

.modal-content {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  border: 2px solid #3c7dcf;
  border-radius: 0;
  box-shadow: none;
}

.modal-header {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  height: 50px;
  padding: 10px;
  background: #2e4411;
  border: 0;
}

.modal-title {
  font-weight: 300;
  font-size: 2em;
  color: #fff;
  line-height: 30px;
}

.modal-body {
  position: absolute;
  top: 50px;
  bottom: 60px;
  width: 100%;
  font-weight: 300;
  overflow: auto;
}

.modal-footer {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  height: 60px;
  padding: 10px;
  background: #f1f3f5;
}

.btn {
  height: 40px;
  border-radius: 0;

  // focus
  &:focus,
  &:active,
  &:active:focus {
    box-shadow: none;
    outline: none;
  }
}

.btn-modal {
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -20px;
  margin-left: -100px;
  width: 200px;
}

.btn-primary,
.btn-primary:hover,
.btn-primary:focus,
.btn-primary:active {
  font-weight: 300;
  font-size: 1.6rem;
  color: #fff;
  color: lighten(#484b5b, 20%);
  color: #fff;
  text-align: center;
  background: #60cc69;
  border: 1px solid #36a940;
  border-bottom: 3px solid #36a940;
  box-shadow: 0 2px 4px rgba(0,0,0,0.15);

  // active
  &:active {
    border-bottom: 1px solid #36a940;
  }
}

.btn-default,
.btn-default:hover,
.btn-default:focus,
.btn-default:active {
  font-weight: 300;
  font-size: 1.6rem;
  color: #fff;
  text-align: center;
  background: darken(#dcdfe4, 10%);
  border: 1px solid darken(#dcdfe4, 20%);
  border-bottom: 3px solid darken(#dcdfe4, 20%);

  // active
  &:active {
    border-bottom: 1px solid darken(#dcdfe4, 20%);
  }
}

.btn-secondary,
.btn-secondary:hover,
.btn-secondary:focus,
.btn-secondary:active {
  color: #cc7272;
  background: transparent;
  border: 0;
}

h1,
h2,
h3 {
  color: #60cc69;
  line-height: 1.5;

  // first
  &:first-child {
    margin-top: 0;
  }
}

p {
  font-size: 1.4em;
  line-height: 1.5;
  color: lighten(#5f6377, 20%);

  // last
  &:last-child {
    margin-bottom: 0;
  }
}

::-webkit-scrollbar {
  -webkit-appearance: none;
  width: 10px;
  background: #f1f3f5;
  border-left: 1px solid darken(#f1f3f5, 10%);
}

::-webkit-scrollbar-thumb {
  background: darken(#f1f3f5, 20%);
}






	</style>		
					
				

    <div class="navbar-lateral full-reset">
        <div class="visible-xs font-movile-menu mobile-menu-button"></div>
        <div class=" container-menu-movile nav-lateral-scroll">
            <div class="logo  all-tittles">
                <i class="visible-xs zmdi zmdi-close pull-left mobile-menu-button" style="line-height: 55px; cursor: pointer; padding: 0 10px; margin-left: 7px;"></i> 
                ESTUDIANTE
            </div>
            <div class="nav-lateral-divider "></div>
            <div class="" style="padding: 10px 0; color:#fff;">
                <figure>
                    <img src="https://i.ibb.co/9VK9YSv/graduation.png" alt="Biblioteca" class="img-responsive center-box" style="width:55%;">
                </figure>
                <p class="text-center" style="padding-top: 15px;"><?php
						echo $_SESSION['admin_login'];
				?></p>
            </div>
        	<div class="nav-lateral-divider "></div>
            <div class="nav-lateral-list-menu">
                <ul class="list-unstyled">
                  
                <li><a  href="../admin/admin_portada.php" style="padding:20px; padding-left:10px;" align="center"><i class="zmdi zmdi-view-dashboard zmdi-hc-fw"></i>&nbsp;&nbsp; Información</a></li>
                    
                    <!-- <a href="../mensajes/mostrar.php"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Mensajes</a></li>  -->
                           <!-- <li><a href="../../folder/grado.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-face zmdi-hc-fw"></i>&nbsp;&nbsp; Académico</a></li> -->
                 <!-- <li><a href="../vista/mensajes/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Cursos</a></li> -->
                 <li><a href="../mensajes/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Cursos</a></li> 
                 <!-- <li><a href="../../folder/docente.php"><i class="zmdi zmdi-male-alt zmdi-hc-fw"></i>&nbsp;&nbsp; Docentes</a></li> -->
                 
                 
                 <!-- <li><a href="#"><i class="zmdi zmdi-wrench zmdi-hc-fw"></i>&nbsp;&nbsp; Herramientas</a></li> -->
                 
                 <li><a href="../../folder/libro.php"style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-dns zmdi-hc-fw"></i>&nbsp;&nbsp; Libreria</a></li>
                 <li><a href="../juegos/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-graphic-eq zmdi-hc-fw"></i>&nbsp;&nbsp; Juegos</a></li>
                 <li><a href="../calendario/mostrar.php"style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-calendar-alt zmdi-hc-fw"></i>&nbsp;&nbsp; Calendario</a></li>
                 <!-- <li><a href="../reporte/mostrar.php"><i class="zmdi zmdi-sort-amount-desc zmdi-hc-fw"></i>&nbsp;&nbsp; Reportes</a></li> -->
                 <!-- <li><a href="#"><i class="zmdi zmdi-money-box zmdi-hc-fw"></i>&nbsp;&nbsp; Contabilidad</a></li> -->
                 <li><a href="../panel_examen/mostrar.php" style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-money-box zmdi-hc-fw"></i></i>&nbsp;&nbsp; Examen</a></li>
                 <li><a href="https://gdenissecedbat.wixsite.com/ingsoft" style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-accounts zmdi-hc-fw"></i></i>&nbsp;&nbsp; Blog</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="content-page-container  custom-scroll-containers  id="mCSB_2_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;background-image: url(https://png.pngtree.com/thumb_back/fw800/background/20210814/pngtree-colorful-geometric-symbols-education-math-formula-background-image_763119.jpg);;" dir="ltr">
        <nav class="navbar-user-top ">
            <ul class="list-unstyled ">
                <figure>
                   <img src="https://i.ibb.co/4jHfNy7/user01.png" alt="user-picture" class="img-responsive img-circle center-box">
                </figure>
                <li style="color:#fff; cursor:default;">
                    <span class="all-tittles"><?php
						echo $_SESSION['admin_login'];
				}
				?></span>
                </li>
                <li  class="tooltips-general exit-system-button" data-href="../vista/cerrar_sesion.php" data-placement="bottom" title="Salir del sistema">
                    <i class="zmdi zmdi-power"></i>
                </li>
                <li  class="tooltips-general search-book-button" data-href="searchbook.html" data-placement="bottom" title="Buscar libro">
                    <i class="zmdi zmdi-search"></i>
                </li>
                <li  class="tooltips-general btn-help" data-placement="bottom" title="Ayuda">
                    <i class="zmdi zmdi-help-outline zmdi-hc-fw"></i>
                </li>
                <li class="mobile-menu-button visible-xs" style="float: left !important;">
                    <i class="zmdi zmdi-menu"></i>
                </li>
                <li class="desktop-menu-button hidden-xs" style="float: left !important;">
                    <i class="zmdi zmdi-swap"></i>
                </li>
            </ul>
        </nav>
		
        <div class="container">
            <div class="page-header">
     
					
					

					
					
					
					
					<?php
			
					include_once('../config/db.php');

					$database = new Connection();
					$db = $database->open();
					try{	
						$sql = 'SELECT * FROM mainlogin WHERE id=1 ';
						foreach ($db->query($sql) as $row) {
							?>
						
								
								
							<?php 
						}
					}
					catch(PDOException $e){
						echo "Hubo un problema en la conexión: " . $e->getMessage();
					}

					$database->close();

						?>
					
				
					</h1>
					
				
					
											<?php

				$user_agent = $_SERVER['HTTP_USER_AGENT'];

				function getBrowser($user_agent){

				if(strpos($user_agent, 'MSIE') !== FALSE)
				   return 'Internet explorer';
				 elseif(strpos($user_agent, 'Edge') !== FALSE) //Microsoft Edge
				   return 'Microsoft Edge';
				 elseif(strpos($user_agent, 'Trident') !== FALSE) //IE 11
					return 'Internet explorer';
				 elseif(strpos($user_agent, 'Opera Mini') !== FALSE)
				   return "Opera Mini";
				 elseif(strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR') !== FALSE)
				   return "Opera";
				 elseif(strpos($user_agent, 'Firefox') !== FALSE)
				   return 'Mozilla Firefox';
				 elseif(strpos($user_agent, 'Chrome') !== FALSE)
				   return 'Google Chrome';
				 elseif(strpos($user_agent, 'Safari') !== FALSE)
				   return "Safari";
				 else
				   return 'No hemos podido detectar su navegador';


				}


				$navegador = getBrowser($user_agent);
				 
			

						?>
							
				
            </div>
        </div>
		
		<?php 
	
	if(isset($_SESSION['message'])){
		?>
		
		
		 <div class="col-sm-12">
		 
                <div class="alert alert-success">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <strong><?php echo $_SESSION['message']; ?>. </strong> 
        </div> 
            </div>
			
			
		<?php

		unset($_SESSION['message']);
		
	}
	
	if(isset($_SESSION['message'])){
		?>
		<div class="alert alert-info text-center" style="margin-top:20px;">
			<?php echo $_SESSION['message']; ?>
		</div>
		<?php

		unset($_SESSION['message']);
	}
		
	
?>

	


			<!-- End of banner image --><!-- Start of text with picture on the left -->			
			<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;background-color:#fff" width="1050" cellspacing="0" cellpadding="0" border="0" bgcolor="#fff" align="center">
				<tbody>
        <tr style="background-color: #fff;">
								<td class="inner title" style="background-color: #fff;">
									<div style="font-size:60px;line-height:42px;color:#115213;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;padding-bottom: 20px;">
									Juegos</div>
								</td>
							</tr>
				<tr>
					<td class="tables-container" style="border: 1px solid gray;">
						<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse; max-width:100%;"><tr><td><![endif]-->
						<table class="col-half" style="border-collapse:collapse; mso-table-lspace:0; mso-table-rspace:0; border-width:0; border-spacing:0;background-color: #fff;" width="50%" cellspacing="0" cellpadding="0" border="0">
							<tbody><tr>
								<td class="spacing1" style=" padding:10px 30px 10px 30px;text-align: center; font-family:'Roboto', Helvetica, Arial, sans-serif; font-weight:300; font-size:18px; line-height:150%; color:#666666; text-align: center;">
									<!-- view modal -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/similarity.png-003d79-128c.png">
<a style="padding-right: 210px; color: black;"
        data-toggle="modal"
        data-target="#fsModal">
 Game Question Limits
</a>
<!-- view modal -->

<!-- modal -->
<div id="fsModal"
     class="modal animated bounceIn"
     tabindex="-1"
     role="dialog"
     aria-labelledby="myModalLabel"
     aria-hidden="true">

  <!-- dialog -->
  <div class="modal-dialog">

    <!-- content -->
    <div class="modal-content">

      <!-- header -->
      <div class="modal-header" st>
        <h1 id="myModalLabel"
            class="modal-title">
			Game Question Limitss
        </h1>
      </div>
      <!-- header -->
      
      <!-- body -->
      <div class="modal-body" align="center"s>
      <iframe 
      style="position:fixed; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%; border:none; margin:0; padding:0; overflow:hidden; z-index:999999;"

      
      src="https://www.educaplay.com/game/6642974-limites_al_infinito.html"></iframe>

      </div>
      <!-- body -->

      <!-- footer -->
      <div class="modal-footer">
        <button class="btn btn-secondary"
                data-dismiss="modal">
          close
        </button>
      </div>
      <!-- footer -->

    </div>
    <!-- content -->

  </div>
  <!-- dialog -->

</div>
<!-- modal -->
									<!-- FIN DE LA INSTRUCCION --><br>
									<!-- FIN DE LA INSTRUCCION -->
									<!-- view modal -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/similarity.png-003d79-128c.png">
<a style="padding-right: 210px; color: black;"
        data-toggle="modal"
        data-target="#fsModal">
Limits Infinity
</a>
<!-- view modal -->

<!-- modal -->
<div id="fsModal"
     class="modal animated bounceIn"
     tabindex="-1"
     role="dialog"
     aria-labelledby="myModalLabel"
     aria-hidden="true">

  <!-- dialog -->
  <div class="modal-dialog">

    <!-- content -->
    <div class="modal-content">

      <!-- header -->
      <div class="modal-header" st>
        <h1 id="myModalLabel"
            class="modal-title">
			Limits Infinitys
        </h1>
      </div>
      <!-- header -->
      
      <!-- body -->
      <div class="modal-body" align="center"s>
	  <iframe width="795" height="690" frameborder="0" src="https://www.educaplay.com/game/6642960-limites_infinito.html"></iframe>

      </div>
      <!-- body -->

      <!-- footer -->
      <div class="modal-footer">
        <button class="btn btn-secondary"
                data-dismiss="modal">
          close
        </button>
      </div>
      <!-- footer -->

    </div>
    <!-- content -->

  </div>
  <!-- dialog -->

</div>
<!-- modal -->
										</tbody></table><br><br></table><br>
	<!-- End of logo with issue number --><!-- Start of banner image -->
	<tr>
	<td style="text-align:center;">
						<img class="banner" alt="image" src="https://3.bp.blogspot.com/-IAZA81rn5WA/WbiPe9XwE4I/AAAAAAAAAJ4/kQaeufSOXlgGxM6OaL0cuBReHUQgV1cIgCLcBGAs/s640/giphy.gif" style="display: block;     padding: 0px 400px;"  vspace="0" hspace="0" border="0">
					</td></tr>
								
	
		
       
	 <script src="../assets/js/reloj.js"></script> 
	 <!-- <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>-->
	 
	<script type="text/javascript">
$(document).ready(function () {
   (function($) {
       $('#FiltrarContenido').keyup(function () {
            var ValorBusqueda = new RegExp($(this).val(), 'i');
            $('.BusquedaRapida tr').hide();
             $('.BusquedaRapida tr').filter(function () {
                return ValorBusqueda.test($(this).text());
              }).show();
                })
      }(jQuery));
});
</script>  
	 
	 	 	 	<script>
$(window).on('load', function () {
      setTimeout(function () {
    $(".loading").css({visibility:"hidden",opacity:"0"})
  }, 500);
     
});
</script>
</body>
</html>