
<!DOCTYPE html>
<html lang="es">
<head>
    <title>Panel administrativo</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" sizes="96x96" href="../../assets/images/icono.svg">
    <script src="../../assets/js/sweet-alert.min.js"></script>
    <link rel="stylesheet" href="../../assets/css/sweet-alert.css">
    <link rel="stylesheet" href="../../assets/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="../../assets/css/normalize.css">
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    
    <script src="../../assets/js/modernizr.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../../assets/js/main.js"></script>
		<style>
			.unir{
				
			}
	 .loading  {
		 position: fixed;
		 left: 0px;
		 top: 0px;
		 width: 100%;
		 height: 100%;
		 z-index: 9999;
		 background: url('../../assets/images/Loading_2.gif') 50% 50% no-repeat rgb(249,249,249);
		opacity: .8; }
	</style>
</head>
<body onload="startTime()">
<div class="loading"></div>
<?php
				session_start();

			
				if(!isset($_SESSION['admin_login']))	
				{
					header("location: ../login.php");  
				}


				if(isset($_SESSION['admin_login']))
				{
				?>
		

    <div class="navbar-lateral full-reset">
        <div class="visible-xs font-movile-menu mobile-menu-button"></div>
        <div class="container-menu-movile nav-lateral-scroll">
            <div class="logo all-tittles">
                <i class="visible-xs zmdi zmdi-close pull-left mobile-menu-button" style="line-height: 55px; cursor: pointer; padding: 0 10px; margin-left: 7px;"></i> 
                ESTUDIANTE
            </div>
            <div class="nav-lateral-divider "></div>
            <div class="#" style="padding: 10px 0; color:#fff;">
                <figure>
                    <img src="../../assets/images/graduation.svg" alt="Biblioteca" class="img-responsive center-box" style="width:55%;">
                </figure>
				<p class="text-center" style="padding-top: 15px;"><?php
						echo $_SESSION['admin_login'];
				?></p>
            </div>
            <div class="nav-lateral-divider "></div>
            <div class=" nav-lateral-list-menu">
                <ul class="list-unstyled">
				<li><a  href="../admin/admin_portada.php" style="padding:20px; padding-left:10px;" align="center"><i class="zmdi zmdi-view-dashboard zmdi-hc-fw"></i>&nbsp;&nbsp; Información</a></li>
                    
					<!-- <a href="../mensajes/mostrar.php"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Mensajes</a></li>  -->
						   <!-- <li><a href="../../folder/grado.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-face zmdi-hc-fw"></i>&nbsp;&nbsp; Académico</a></li> -->
						   <!-- <li><a href="../vista/mensajes/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Cursos</a></li> -->
						   <li><a href="../mensajes/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Cursos</a></li> 
						   <!-- <li><a href="../../folder/docente.php"><i class="zmdi zmdi-male-alt zmdi-hc-fw"></i>&nbsp;&nbsp; Docentes</a></li> -->
						   
						   
						   <!-- <li><a href="#"><i class="zmdi zmdi-wrench zmdi-hc-fw"></i>&nbsp;&nbsp; Herramientas</a></li> -->
						   
						   <li><a href="../../folder/libro.php"style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-dns zmdi-hc-fw"></i>&nbsp;&nbsp; Libreria</a></li>
						   <li><a href="../juegos/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-graphic-eq zmdi-hc-fw"></i>&nbsp;&nbsp; Juegos</a></li>
						   <li><a href="../calendario/mostrar.php"style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-calendar-alt zmdi-hc-fw"></i>&nbsp;&nbsp; Calendario</a></li>
						   <!-- <li><a href="../reporte/mostrar.php"><i class="zmdi zmdi-sort-amount-desc zmdi-hc-fw"></i>&nbsp;&nbsp; Reportes</a></li> -->
						   <!-- <li><a href="#"><i class="zmdi zmdi-money-box zmdi-hc-fw"></i>&nbsp;&nbsp; Contabilidad</a></li> -->
						   <li><a href="../panel_examen/mostrar.php" style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-money-box zmdi-hc-fw"></i></i>&nbsp;&nbsp; Examen</a></li>
						   <li><a href="https://gdenissecedbat.wixsite.com/ingsoft" style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-accounts zmdi-hc-fw"></i></i>&nbsp;&nbsp; Blog</a></li>
                </ul>
            </div>
        </div>
    </div>

	<div class="content-page-container  custom-scroll-containers">
        <nav class="navbar-user-top ">
            <ul class="list-unstyled  form-style">
                <figure>
                   <img src="../../assets/images/user01.png" alt="user-picture" class="img-responsive img-circle center-box">
                </figure>
                <li style="color:#fff; cursor:default;">
                    <span class="all-tittles">
					<?php
						echo $_SESSION['admin_login'];
				}
				?></span>
                </li>
                <li  class="tooltips-general exit-system-button" data-href="../cerrar_sesion.php" data-placement="bottom" title="Salir del sistema">
                    <i class="zmdi zmdi-power"></i>
                </li>
                <li  class="tooltips-general search-book-button" data-href="searchbook.html" data-placement="bottom" title="Buscar libro">
                    <i class="zmdi zmdi-search"></i>
                </li>
				
				
	
				
				
                <li  class="tooltips-general btn-help" data-placement="bottom" title="Ayuda">
                    <i class="zmdi zmdi-help-outline zmdi-hc-fw"></i>
                </li>
				
                <li class="mobile-menu-button visible-xs" style="float: left !important;">
                    <i class="zmdi zmdi-menu"></i>
                </li>
                <li class="desktop-menu-button hidden-xs" style="float: left !important;">
                    <i class="zmdi zmdi-swap"></i>
                </li>
            </ul>
        </nav>
		
		
        <div class="container">
            <div class="page-header">
              <h1 class="all-tittles">
              <img src="http://localhost/tarea/RP_v2/RP_v2/assets/images/logo-preu.png" align="right" style="width: 100px;">		
			  <?php 
					$hora= getdate();
					
					
					$a="BIENVENIDOS";
					$b="BIENVENIDOS";
					$c="Buenas noches";

					if ($hora<12 =='$a'){
					echo "","<font color='green'>$a</font>";
					}
					
					elseif ($hora >=12 =='$b')
					{
					echo "","<font color='green'>$b</font>";	
					}
					elseif ($hora <=16 =='$b')
					{
					echo "","<font color='green'>$b</font>";	
					}
					
					
					elseif ($hora >=19 =='$c')
					{
					echo "","<font color='green'>$c</font>";	
					}
					elseif ( $hora >=24 =='$c')
					{
					echo "","<font color='green'>$c</font>";	
					}
					
					
					
					?> 
					
					
					
					<?php
			
					include_once('../config/db.php');

					$database = new Connection();
					$db = $database->open();
					try{	
						$sql = 'SELECT * FROM mainlogin WHERE id=1 ';
						foreach ($db->query($sql) as $row) {
							?>
						
								
								
							<?php 
						}
					}
					catch(PDOException $e){
						echo "Hubo un problema en la conexión: " . $e->getMessage();
					}

					$database->close();

						?>
					
					
					
					</h1>
					
					<h5>
					<strong>Tu último acceso es:</strong>
					<div id="date" style="margin-left:100px; margin-top:-15px;"></div>
					 
					</h5>
					
											<?php

				$user_agent = $_SERVER['HTTP_USER_AGENT'];

				function getBrowser($user_agent){

				if(strpos($user_agent, 'MSIE') !== FALSE)
				   return 'Internet explorer';
				 elseif(strpos($user_agent, 'Edge') !== FALSE) //Microsoft Edge
				   return 'Microsoft Edge';
				 elseif(strpos($user_agent, 'Trident') !== FALSE) //IE 11
					return 'Internet explorer';
				 elseif(strpos($user_agent, 'Opera Mini') !== FALSE)
				   return "Opera Mini";
				 elseif(strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR') !== FALSE)
				   return "Opera";
				 elseif(strpos($user_agent, 'Firefox') !== FALSE)
				   return 'Mozilla Firefox';
				 elseif(strpos($user_agent, 'Chrome') !== FALSE)
				   return 'Google Chrome';
				 elseif(strpos($user_agent, 'Safari') !== FALSE)
				   return "Safari";
				 else
				   return 'No hemos podido detectar su navegador';


				}


				$navegador = getBrowser($user_agent);
				 
				echo "<strong>Navegador</strong>: ".$navegador;

						?>
					
				
            </div>
        </div>
			<!-- End of banner image --><!-- Start of text with picture on the left -->			
			<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;background-color:#fff" width="1050" cellspacing="0" cellpadding="0" border="0" bgcolor="#fff" align="center">
				<tbody>
				<tr>
					<td class="tables-container" >
						<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse; max-width:100%;"><tr><td><![endif]-->
						<table class="col-half" style="border-collapse:collapse; mso-table-lspace:0; mso-table-rspace:0; border-width:0; border-spacing:0;" width="50%" cellspacing="0" cellpadding="0" border="0" align="right">
							<tbody><tr>
							<td class="spacing1" style=" padding:50px 30px 10px 1px;text-align: center; font-family:'Roboto', Helvetica, Arial, sans-serif; font-weight:300; font-size:18px; line-height:150%; color:#666666; text-align: center;">
								<span style="padding-right: 100%;">Práctica</span>
								</td>
							</tr>
							<tr>
							<td bgcolor="#d5ddd5">
								<!-- Button trigger modal -->
								<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;" src="https://w7.pngwing.com/pngs/418/601/png-transparent-computer-icons-pencil-pencil-angle-pencil-logo.png">
									<a style="float:left; color: black;    padding-left: 10px; " href data-toggle="modal" data-target="#exampleModalCenter23">
									Evalúa funciones compuestas<br><font style="font-size:15px" color="#666666" >3 Preguntas</font>
								<b>	<font style="font-size:15px;   padding-left: 330px; " color="#012326" >Práctica</font></b>
									</a><br>
									<!-- Modal 1.0 -->
									<div class="modal fade" style="padding:130px 0px 0px 160px !important;" id="exampleModalCenter23" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#b69960;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle">Práctica</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
										<a href="https://ibb.co/Xxkcn4C"><img src="https://i.ibb.co/HTp5c2H/Whats-App-Image-2022-06-30-at-3-52-37-PM.jpg" alt="Whats-App-Image-2022-06-30-at-3-52-37-PM" border="0"></a>
<a href="https://imgbb.com/"><img src="https://i.ibb.co/6wzk6Qk/Whats-App-Image-2022-06-30-at-3-53-01-PM.jpg" alt="Whats-App-Image-2022-06-30-at-3-53-01-PM" border="0"></a>
<a href="https://imgbb.com/"><img src="https://i.ibb.co/DKS5p9x/Whats-App-Image-2022-06-30-at-3-53-28-PM.jpg" alt="Whats-App-Image-2022-06-30-at-3-53-28-PM" border="0"></a>
										
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
									<!-- FIN DE LA INSTRUCCION -->
										<!-- Button trigger modal -->
							</td>
							</tr>
						</tbody></table>
						
						<table class="col-half" style="border-collapse:collapse; mso-table-lspace:0; mso-table-rspace:0; border-width:0; border-spacing:0;background-color: #fff;" width="50%" cellspacing="0" cellpadding="0" border="0">
							<tbody><tr>
							<tr>
								<td class="inner title" >
									<div style="font-size:34px;line-height:42px;color:#b69960;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center">
									A.Funciones trigonométricas inversas</div>
								</td>
							</tr>
								<td class="spacing1" style=" padding:10px 30px 10px 30px;text-align: center; font-family:'Roboto', Helvetica, Arial, sans-serif; font-weight:300; font-size:18px; line-height:150%; color:#666666; text-align: center;">
								<span style="padding-right: 100%;">Aprende</span>
									<!-- Button trigger modal -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAxlBMVEX///9Pvp8JgWzc3+Lr7vJKvZ0AfWlDspVCu5ry8fZ7x7MAemM+uphRwKEAfGZ/y7a/5Nnk5+ux4NLu+fbH6d/k9fDc8evS7eWN07/r+PRpx6xzybB9zbae2cdawqXk4udNmYvM4+DS2dyq3c6qycWT1cIWiXMsnII4kH82pYq41M3C2NOsz8bc6OnQ4+KSzLxWtZ2Xwbl/uq5jtKHD0dKHvLKKs65tqJ07q45ov6ikwL0ki3gunYOgzsFfp5eiyMBsrZ83mYVJFARiAAAHCklEQVR4nO2dbVfaTBCGS0JCNC8ghIgBAmiNraV9Wp5qrbS1/v8/1U3Al0DAJPfuZjlnri9t9ZweL2cnOzu7ZN+9IwiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIIrTO+sHwSnD9/3OCva35AtB0D/r1f3jVaQX+J3ueDAMo0bDYFj5JN9qNKJwOBh3O35wALa9vt8dt0PXcdY/f6MY69+B47hhe9z1+wqqsphdDIaR4SReBbV2yTJTIxoOLpSJad8fjyK3TMSKilpuNBr7Qa1yncsoHY4c1TZEk/8+uuzUoHnmj4eWI9At6+lYw3HnTJpd0G1HcL6VtmThjEZd8cEMuiNX5LB8Q5Pl5vBCoOXpQNrA3GfpWG1fiF8ndOq2e8Kwoi53v35o1e2VwYo4D9ZO7aNzE8O54Ck4duoWysEacBRUa4Q+YbV5CXbVFGw0nDEfwVNVBVkU+UwboWoPmVe4PNYfyo7RBOuSg6HCEWQ4eBCVDiELIv6wUTkLE1xU8ExxwYaFVm++2oOUGaLF21j1GBpoYTNS3bARgoZh3QJvEmHzRS+qW+BNDKxDpfyjFH6Y9lV/lMLVt/KTBTxdKF6zJRhY3ab8dAhPiIMDMBxChkP1DRsRZKj+dMgeNZDhAYQQWwT3VOyTbgJN+f2DMESmfIUbiS9YHcCwcxCGSFFzACUNmxCRjiKHDQvxu+HGCDC8RH88J2wPRW/MGcgqH+xhGNGsedT8PBD8REaKGqxZaoTMj3H0JRQaRwMwxIo2Y5YKJswjgYoOYIg9aMJnweaR/p+4MCJlG5RAxujFsNmcnP8UNfU4QC8KM2y/Nmzqk/dfxTha/cqCWOG9YdjUdf1bS8RQtU4rG2Kdtk3DE12fnC8EHDsCDAOuhkkQ9cn3/7k/coDFBba02DI80VNH7ukILC6wbumWYRpEnX86WtUPufE2PFkbck5Ho/ryCVsebhs+BzFNR16CSE8YWx7mGJ7oL4780hFYIF4INOSYjkb1I3yg4fGWYTNjyNKRy8wBLIGxXYs3DXnNjiob8klHwBBrYhQy5JGOwN4MtvNU1BBOR+UN8dmxeiuqLcmQwdLRrcEQa7WVMtT1m1ZlxQMxnNxeNSo6KmR4ssdQ1z9oH6s5Horh5NYz4zu3gqNChntDqH/zNM2MK6Rj9aa3XEMWQ40pmldGWUd1Yrg/DVkeppjax5JDVR3DAiFcObKhWsZRGcP9Iby1tRfMuMxQVaWm2St4v/S015jar+IzR3VDvnXpngH6fZr1W4WxaDqqUnnv9jv/4W0LlkhHwJDn+nD3GL3N90sdCxVyaqzxdwlO3n+wd/mlFEhHJQx3COYmYOl0VKHXli+4MwFLpqMChrmCE/1WK+BXIB2BjjDY834yzBd8KwGz7EtH4BN64L7F2jBPsEACbg7V3esqYGcG3HtaGeYIsgQsE78nx13pWN/uWmqYF8HCCbjhuCMdgR1ScA84MdwWLJmAWXLbHMAuN7iPzwy3BEsn4EYY89KxvrMYx0ebgkkCmoCglpuOwEFv8DzN8Va1fRsjAVwrapvpCJwYAs9E/ZzwS8CsY7aQq+9cW8aQJSAfv9Qxk46IIba19zWTgEVK0DKOL11H5PQldL7Uvbt/DuK3JVc/LZOOyAla6Iyw29LOJ+sE5O23clynI3IKGmq2uS1Pu2eCPBNwwzGdOaCP50FtDLdlarb2YSnK78kR+ogltEBMDCXwC/pECbRAlGRoer8BQ2iBKMlQsx8AQ2hxIc1wDhhCnz+UZjgDDKHSW5oh9GIMQFCeISIIlW2yDDXIEPk8vizDJWSI7D7Jmg+nkCGycyHJ0PsBGSJFjSzDBWSIdEwlGdpI0YZ122QZfoIMkfdEyTL8DBki7/qSNVsAvcQE4H1tkgyX4Ps9gT6GJMMpJohMiHIMzT+gITBdyDGE1r8JwMNUjqGHrA5TqrdM5RjGqCBQt0kx9G5gw+ovw5JiaHN4oXflIMowtDmEsHomyjCMudwJVbWlKMHQvuYhWHmcCjc0NWzh9Ipqr4sSbGhqV5wuf0gVq/RNxRqaV7xut1hR5Z4ZkYZm3ALOeuVS4a4gcYZmfGeF4LIwh9L3PYkyNLWPVoi8SXA3qzu7CmuKMTTtK2sg5s6ulDL3rvE39DxbexR579qzZbG78/gaerYd/1nMpF0RWOT+Q26GTM5+XPz+LP/Wzn7nMtxzhyUHQzORi/8+wKtcSNMfj0LXyhm2kGHipi2ni+ta5V7I3CVrIIaml4Zt+ncx/8J/xoPZuA+4Vfisl5d6sajF05ubedBT5J7cPazudD5+XMavfvxt2HfYLyFePv5ZPMznvoIxK8RZcDqbzT4xrq+v53Omwv5M/sm+OgtUvL+ZIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAhCXf4BOEriBeNbNQgAAAAASUVORK5CYII=">
									<a style="float:left; color: black;    padding-left: 10px; " href data-toggle="modal" data-target="#example3">
									1.0 - Funciones trigonométricas inversas<br>
									</a><br>
									<!-- Modal 1.0 -->
									<div class="modal fade" style="padding:130px 0px 0px 160px !important;" id="example3" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#b69960;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle"> Introducción a los números imaginarios</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
										<iframe width="560" height="315" src="https://www.youtube.com/embed/hUuG-7_PcdY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
									<!-- FIN DE LA INSTRUCCION -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;" src="https://img1.freepng.es/20180518/epl/kisspng-computer-icons-report-chart-5aff9ed76bbf05.3122690215267017834413.jpg">
									<a style="float:left; color: black;    padding-left: 10px; " href data-toggle="modal" data-target="#exampleModalCenter2">
									1.0 - Introducción a la Composición de funciones
									</a><br>
									<!-- Modal 1.0 -->
									<div id="exampleModalCenter2" class="modal fade" style="padding:130px 0px 0px 160px !important;"  tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#022601;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle"> Introducción a los números imaginarios</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										
										<div class="modal-body">
											<!-- End of banner image --><!-- Start of short intro text -->			
			<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;" width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
				<tbody>
				<tr>
					<td class="inner title" style="padding:30px 30px 5px 30px;">
						<div style="
						color: #21242c;
    					font-size: 19px;s
   						 line-height: 30px;
    					margin-bottom: 32px;
    					margin-top: 0;
						font-family:'Libre Bodoni','times new roman','serif'!important;font-weight:400!important;text-align:left">
						Cam es un agricultor. Cada año siembra semillas de maíz. La siguiente función indica la cantidad de maíz, CCC en kilogramos (kg), que él espera cosechar en aaa acres de terreno.
			<br><br>			Por ejemplo, si Cam siembra dos acres, él espera cosechar C( 2) = 7500( 2)-1500= {13{,}{500}}C(2)=7500(2)−1500=13,500C, left parenthesis, 2, right parenthesis, equals, 7500, left parenthesis, 2, right parenthesis, minus, 1500, equals, 13, comma, 500 \text{kg}kgstart text, k, g, end text de maíz.
	<br><br>		Pero a Cam le interesa más saber cuánto dinero ganará al vender su maíz. Así que utiliza la siguiente función para predecir la cantidad de dinero, MMM en pesos, que él obtendrá al vender ccc kilogramos de maíz.
	<img  style=" float:center;" src="https://i.ibb.co/XZ8p6L3/123.png">
						</div>
					</td>
				</tr>
			</tbody></table>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
							<!-- FIN DE LA INSTRUCCION -->
								</td>
								<!-- FIN DE LA COLUMNA -->
								
							</tr>
							<tr>
					<!-- <td class="spacing2" style="text-align: center;"  >
						<span class="bottom_yellow" href="#" >explore more>></span>
					</td> -->
				</tr>
						</tbody></table>
						<!--[if mso]></td></tr></table><![endif]-->
					</td>
				</tr>
			</tbody></table><br><br>

        <!-- *************************** COMIENZO DE TEMA#2************* -->

		<!-- End of banner image --><!-- Start of text with picture on the left -->			
		<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;background-color:#fff" width="1050" cellspacing="0" cellpadding="0" border="0" bgcolor="#fff" align="center">
				<tbody>
				<tr>
					<td class="tables-container" >
						<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse; max-width:100%;"><tr><td><![endif]-->
						<table class="col-half" style="border-collapse:collapse; mso-table-lspace:0; mso-table-rspace:0; border-width:0; border-spacing:0;" width="50%" cellspacing="0" cellpadding="0" border="0" align="right">
							<tbody><tr>
							<td class="spacing1" style=" padding:50px 30px 10px 1px;text-align: center; font-family:'Roboto', Helvetica, Arial, sans-serif; font-weight:300; font-size:18px; line-height:150%; color:#666666; text-align: center;">
								<span style="padding-right: 100%;">Práctica</span>
								</td>
							</tr>
							<tr>
							<td bgcolor="#d5ddd5">
							<!-- Button trigger modal -->
							<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;" src="https://w7.pngwing.com/pngs/418/601/png-transparent-computer-icons-pencil-pencil-angle-pencil-logo.png">
									<a style="float:left; color: black;    padding-left: 10px; " href data-toggle="modal" data-target="#exampleModalCenter234">
									Modela con funciones compuestas<br><font style="font-size:15px" color="#666666" >3 Preguntas</font>
								<b>	<font style="font-size:15px;   padding-left: 330px; " color="#012326" >Práctica</font></b>
									</a><br>
									<!-- Modal 1.0 -->
									<div class="modal fade" style="padding:130px 0px 0px 160px !important;" id="exampleModalCenter234" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#b69960;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle">Práctica</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
										<a href="https://ibb.co/Zd47Mqd"><img src="https://i.ibb.co/Jn6gsDn/Whats-App-Image-2022-06-30-at-4-05-34-PM.jpg" alt="Whats-App-Image-2022-06-30-at-4-05-34-PM" border="0"></a>
<a href="https://ibb.co/sRwnk4F"><img src="https://i.ibb.co/H4z61yr/Whats-App-Image-2022-06-30-at-4-06-00-PM.jpg" alt="Whats-App-Image-2022-06-30-at-4-06-00-PM" border="0"></a>
<a href="https://imgbb.com/"><img src="https://i.ibb.co/frZzFpL/Whats-App-Image-2022-06-30-at-4-06-16-PM.jpg" alt="Whats-App-Image-2022-06-30-at-4-06-16-PM" border="0"></a>s
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
									<!-- FIN DE LA INSTRUCCION -->
										<!-- Button trigger modal -->
							
							</td>
							</tr>
						</tbody></table>
						
						<table class="col-half" style="border-collapse:collapse; mso-table-lspace:0; mso-table-rspace:0; border-width:0; border-spacing:0;background-color: #fff;" width="50%" cellspacing="0" cellpadding="0" border="0">
							<tbody><tr>
							<tr>
								<td class="inner title" >
									<div style="font-size:35px;line-height:42px;color:#b69960;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center">
									B.Ecuaciones sinusoidales</div>
								</td>
							</tr>
								<td class="spacing1" style=" padding:10px 30px 10px 30px;text-align: center; font-family:'Roboto', Helvetica, Arial, sans-serif; font-weight:300; font-size:18px; line-height:150%; color:#666666; text-align: center;">
								<span style="padding-right: 100%;">Aprende</span>
									<!-- Button trigger modal -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAxlBMVEX///9Pvp8JgWzc3+Lr7vJKvZ0AfWlDspVCu5ry8fZ7x7MAemM+uphRwKEAfGZ/y7a/5Nnk5+ux4NLu+fbH6d/k9fDc8evS7eWN07/r+PRpx6xzybB9zbae2cdawqXk4udNmYvM4+DS2dyq3c6qycWT1cIWiXMsnII4kH82pYq41M3C2NOsz8bc6OnQ4+KSzLxWtZ2Xwbl/uq5jtKHD0dKHvLKKs65tqJ07q45ov6ikwL0ki3gunYOgzsFfp5eiyMBsrZ83mYVJFARiAAAHCklEQVR4nO2dbVfaTBCGS0JCNC8ghIgBAmiNraV9Wp5qrbS1/v8/1U3Al0DAJPfuZjlnri9t9ZweL2cnOzu7ZN+9IwiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIIrTO+sHwSnD9/3OCva35AtB0D/r1f3jVaQX+J3ueDAMo0bDYFj5JN9qNKJwOBh3O35wALa9vt8dt0PXcdY/f6MY69+B47hhe9z1+wqqsphdDIaR4SReBbV2yTJTIxoOLpSJad8fjyK3TMSKilpuNBr7Qa1yncsoHY4c1TZEk/8+uuzUoHnmj4eWI9At6+lYw3HnTJpd0G1HcL6VtmThjEZd8cEMuiNX5LB8Q5Pl5vBCoOXpQNrA3GfpWG1fiF8ndOq2e8Kwoi53v35o1e2VwYo4D9ZO7aNzE8O54Ck4duoWysEacBRUa4Q+YbV5CXbVFGw0nDEfwVNVBVkU+UwboWoPmVe4PNYfyo7RBOuSg6HCEWQ4eBCVDiELIv6wUTkLE1xU8ExxwYaFVm++2oOUGaLF21j1GBpoYTNS3bARgoZh3QJvEmHzRS+qW+BNDKxDpfyjFH6Y9lV/lMLVt/KTBTxdKF6zJRhY3ab8dAhPiIMDMBxChkP1DRsRZKj+dMgeNZDhAYQQWwT3VOyTbgJN+f2DMESmfIUbiS9YHcCwcxCGSFFzACUNmxCRjiKHDQvxu+HGCDC8RH88J2wPRW/MGcgqH+xhGNGsedT8PBD8REaKGqxZaoTMj3H0JRQaRwMwxIo2Y5YKJswjgYoOYIg9aMJnweaR/p+4MCJlG5RAxujFsNmcnP8UNfU4QC8KM2y/Nmzqk/dfxTha/cqCWOG9YdjUdf1bS8RQtU4rG2Kdtk3DE12fnC8EHDsCDAOuhkkQ9cn3/7k/coDFBba02DI80VNH7ukILC6wbumWYRpEnX86WtUPufE2PFkbck5Ho/ryCVsebhs+BzFNR16CSE8YWx7mGJ7oL4780hFYIF4INOSYjkb1I3yg4fGWYTNjyNKRy8wBLIGxXYs3DXnNjiob8klHwBBrYhQy5JGOwN4MtvNU1BBOR+UN8dmxeiuqLcmQwdLRrcEQa7WVMtT1m1ZlxQMxnNxeNSo6KmR4ssdQ1z9oH6s5Horh5NYz4zu3gqNChntDqH/zNM2MK6Rj9aa3XEMWQ40pmldGWUd1Yrg/DVkeppjax5JDVR3DAiFcObKhWsZRGcP9Iby1tRfMuMxQVaWm2St4v/S015jar+IzR3VDvnXpngH6fZr1W4WxaDqqUnnv9jv/4W0LlkhHwJDn+nD3GL3N90sdCxVyaqzxdwlO3n+wd/mlFEhHJQx3COYmYOl0VKHXli+4MwFLpqMChrmCE/1WK+BXIB2BjjDY834yzBd8KwGz7EtH4BN64L7F2jBPsEACbg7V3esqYGcG3HtaGeYIsgQsE78nx13pWN/uWmqYF8HCCbjhuCMdgR1ScA84MdwWLJmAWXLbHMAuN7iPzwy3BEsn4EYY89KxvrMYx0ebgkkCmoCglpuOwEFv8DzN8Va1fRsjAVwrapvpCJwYAs9E/ZzwS8CsY7aQq+9cW8aQJSAfv9Qxk46IIba19zWTgEVK0DKOL11H5PQldL7Uvbt/DuK3JVc/LZOOyAla6Iyw29LOJ+sE5O23clynI3IKGmq2uS1Pu2eCPBNwwzGdOaCP50FtDLdlarb2YSnK78kR+ogltEBMDCXwC/pECbRAlGRoer8BQ2iBKMlQsx8AQ2hxIc1wDhhCnz+UZjgDDKHSW5oh9GIMQFCeISIIlW2yDDXIEPk8vizDJWSI7D7Jmg+nkCGycyHJ0PsBGSJFjSzDBWSIdEwlGdpI0YZ122QZfoIMkfdEyTL8DBki7/qSNVsAvcQE4H1tkgyX4Ps9gT6GJMMpJohMiHIMzT+gITBdyDGE1r8JwMNUjqGHrA5TqrdM5RjGqCBQt0kx9G5gw+ovw5JiaHN4oXflIMowtDmEsHomyjCMudwJVbWlKMHQvuYhWHmcCjc0NWzh9Ipqr4sSbGhqV5wuf0gVq/RNxRqaV7xut1hR5Z4ZkYZm3ALOeuVS4a4gcYZmfGeF4LIwh9L3PYkyNLWPVoi8SXA3qzu7CmuKMTTtK2sg5s6ulDL3rvE39DxbexR579qzZbG78/gaerYd/1nMpF0RWOT+Q26GTM5+XPz+LP/Wzn7nMtxzhyUHQzORi/8+wKtcSNMfj0LXyhm2kGHipi2ni+ta5V7I3CVrIIaml4Zt+ncx/8J/xoPZuA+4Vfisl5d6sajF05ubedBT5J7cPazudD5+XMavfvxt2HfYLyFePv5ZPMznvoIxK8RZcDqbzT4xrq+v53Omwv5M/sm+OgtUvL+ZIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAhCXf4BOEriBeNbNQgAAAAASUVORK5CYII=">
									<a style="float:left; color: black;    padding-left: 10px; " href data-toggle="modal" data-target="#example4">
									2.0 - Modelar con composición de funciones<br>
									</a><br>
									<!-- Modal 1.0 -->
									<div class="modal fade" style="padding:130px 0px 0px 160px !important;" id="example4" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#b69960;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle"> Introducción a los números complejos</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
										<iframe width="560" height="315" src="https://www.youtube.com/embed/Qw9GTgSv_94" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
									<!-- FIN DE LA INSTRUCCION -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;" src="https://img1.freepng.es/20180518/epl/kisspng-computer-icons-report-chart-5aff9ed76bbf05.3122690215267017834413.jpg">
									<a style="float:left; color: black;    padding-left: 10px; " href data-toggle="modal" data-target="#exampleModalCenter2">
									2.0 - Introducción a los números complejos
									</a><br>
									<!-- Modal 1.0 -->
									<div id="exampleModalCenter2" class="modal fade" style="padding:130px 0px 0px 160px !important;"  tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#022601;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle"> Introducción a los números complejos</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
							<iframe width="560" height="315" src="https://www.youtube.com/embed/GGIDDBJtk4s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
						
						
						</div>
					</td>
				</tr>
			</tbody></table>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
							<!-- FIN DE LA INSTRUCCION -->
								</td>
								<!-- FIN DE LA COLUMNA -->
								
							</tr>
							<tr>
					<!-- <td class="spacing2" style="text-align: center;"  >
						<span class="bottom_yellow" href="#" >explore more>></span>
					</td> -->
				</tr>
						</tbody></table>
						<!--[if mso]></td></tr></table><![endif]-->
					</td>
				</tr>
			</tbody></table>
	 <script src="../../assets/js/reloj.js"></script> 
	 	<script>
$(window).on('load', function () {
      setTimeout(function () {
    $(".loading").css({visibility:"hidden",opacity:"0"})
  }, 500);
     
});
</script>
</body>
</html>
