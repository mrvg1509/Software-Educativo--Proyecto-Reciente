
<!DOCTYPE html>
<html lang="es">
<head>
    <title>Panel administrativo</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" sizes="96x96" href="../../assets/images/icono.svg">
    <script src="../../assets/js/sweet-alert.min.js"></script>
    <link rel="stylesheet" href="../../assets/css/sweet-alert.css">
    <link rel="stylesheet" href="../../assets/css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="../../assets/css/normalize.css">
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    
    <script src="../../assets/js/modernizr.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../../assets/js/main.js"></script>
		<style>
			.unir{
				
			}
	 .loading  {
		 position: fixed;
		 left: 0px;
		 top: 0px;
		 width: 100%;
		 height: 100%;
		 z-index: 9999;
		 background: url('../../assets/images/Loading_2.gif') 50% 50% no-repeat rgb(249,249,249);
		opacity: .8; }
	</style>
</head>
<body onload="startTime()">
<div class="loading"></div>
<?php
				session_start();

				if(!isset($_SESSION['admin_login']))	
				{
					header("location: ../login.php");  
				}


				if(isset($_SESSION['admin_login']))
				{
				?>
		

    <div class="navbar-lateral full-reset">
        <div class="visible-xs font-movile-menu mobile-menu-button"></div>
        <div class="container-menu-movile nav-lateral-scroll">
            <div class="logo all-tittles">
                <i class="visible-xs zmdi zmdi-close pull-left mobile-menu-button" style="line-height: 55px; cursor: pointer; padding: 0 10px; margin-left: 7px;"></i> 
                ESTUDIANTE
            </div>
            <div class="nav-lateral-divider "></div>
            <div class="#" style="padding: 10px 0; color:#fff;">
                <figure>
                    <img src="../../assets/images/graduation.svg" alt="Biblioteca" class="img-responsive center-box" style="width:55%;">
                </figure>
				<p class="text-center" style="padding-top: 15px;"><?php
						echo $_SESSION['admin_login'];
				?></p>
            </div>
            <div class="nav-lateral-divider "></div>
            <div class=" nav-lateral-list-menu">
                <ul class="list-unstyled">
                    <li><a  href="../admin/admin_portada.php" style="padding:20px; padding-left:10px;" align="center"><i class="zmdi zmdi-view-dashboard zmdi-hc-fw"></i>&nbsp;&nbsp; Información</a></li>
                    
             <!-- <a href="../mensajes/mostrar.php"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Mensajes</a></li>  -->
                    <!-- <li><a href="../../folder/grado.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-face zmdi-hc-fw"></i>&nbsp;&nbsp; Académico</a></li> -->
					<!-- <li><a href="../vista/mensajes/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Cursos</a></li> -->
					<li><a href="../mensajes/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-favorite zmdi-hc-fw"></i>&nbsp;&nbsp; Cursos</a></li> 
					<!-- <li><a href="../../folder/docente.php"><i class="zmdi zmdi-male-alt zmdi-hc-fw"></i>&nbsp;&nbsp; Docentes</a></li> -->
					
					
					<!-- <li><a href="#"><i class="zmdi zmdi-wrench zmdi-hc-fw"></i>&nbsp;&nbsp; Herramientas</a></li> -->
					
					<li><a href="../../folder/libro.php"style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-dns zmdi-hc-fw"></i>&nbsp;&nbsp; Libreria</a></li>
					<li><a href="../juegos/mostrar.php"style="padding:20px; padding-left:5px;"align="center"><i class="zmdi zmdi-graphic-eq zmdi-hc-fw"></i>&nbsp;&nbsp; Juegos</a></li>
					<li><a href="../calendario/mostrar.php"style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-calendar-alt zmdi-hc-fw"></i>&nbsp;&nbsp; Calendario</a></li>
					<!-- <li><a href="../reporte/mostrar.php"><i class="zmdi zmdi-sort-amount-desc zmdi-hc-fw"></i>&nbsp;&nbsp; Reportes</a></li> -->
					<!-- <li><a href="#"><i class="zmdi zmdi-money-box zmdi-hc-fw"></i>&nbsp;&nbsp; Contabilidad</a></li> -->
					<li><a href="../panel_examen/mostrar.php" style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-money-box zmdi-hc-fw"></i></i>&nbsp;&nbsp; Examen</a></li>
					<li><a href="https://gdenissecedbat.wixsite.com/ingsoft" style="padding:20px; padding-left:10px;"align="center"><i class="zmdi zmdi-accounts zmdi-hc-fw"></i></i>&nbsp;&nbsp; Blog</a></li>
                </ul>
            </div>
        </div>
    </div>

	<div class="content-page-container  custom-scroll-containers  id="mCSB_2_container" class="mCSB_container" style="position: relative;top: 0px;left: 0px;/* background-color: aqua; */background-image: url(https://i.pinimg.com/564x/c6/95/f3/c695f3079d7536e2d9ec79a6ed2dfe36.jpg);;" dir="ltr">
        <nav class="navbar-user-top ">
            <ul class="list-unstyled  form-style">
                <figure>
                   <img src="../../assets/images/user01.png" alt="user-picture" class="img-responsive img-circle center-box">
                </figure>
                <li style="color:#fff; cursor:default;">
                    <span class="all-tittles">
					<?php
						echo $_SESSION['admin_login'];
				}
				?></span>
                </li>
                <li  class="tooltips-general exit-system-button" data-href="../cerrar_sesion.php" data-placement="bottom" title="Salir del sistema">
                    <i class="zmdi zmdi-power"></i>
                </li>
                <li  class="tooltips-general search-book-button" data-href="searchbook.html" data-placement="bottom" title="Buscar libro">
                    <i class="zmdi zmdi-search"></i>
                </li>
				
				
	
				
				
                <li  class="tooltips-general btn-help" data-placement="bottom" title="Ayuda">
                    <i class="zmdi zmdi-help-outline zmdi-hc-fw"></i>
                </li>
				
                <li class="mobile-menu-button visible-xs" style="float: left !important;">
                    <i class="zmdi zmdi-menu"></i>
                </li>
                <li class="desktop-menu-button hidden-xs" style="float: left !important;">
                    <i class="zmdi zmdi-swap"></i>
                </li>
            </ul>
        </nav>
		
			<!-- End of text with picture on the left --><!-- Start of text with picture on the right -->			
			<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;" width="1170" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
				<tbody>
				<tr>
					<td class="tables-container space_line " style="padding:0px 0px 0px 0px; background-color: white;">
        <div class="container">
            <div class="page-header">
              <h1 class="all-tittles">
              <img src="http://localhost/tarea/RP_v2/RP_v2/assets/images/logo-preu.png" align="right" style="width: 100px;">		
			  <?php 
					$hora= getdate();
					
					
					$a="BIENVENIDOS";
					$b="BIENVENIDOS";
					$c="Buenas noches";

					if ($hora<12 =='$a'){
					echo "","<font color='green'>$a</font>";
					}
					
					elseif ($hora >=12 =='$b')
					{
					echo "","<font color='green'>$b</font>";	
					}
					elseif ($hora <=16 =='$b')
					{
					echo "","<font color='green'>$b</font>";	
					}
					
					
					elseif ($hora >=19 =='$c')
					{
					echo "","<font color='green'>$c</font>";	
					}
					elseif ( $hora >=24 =='$c')
					{
					echo "","<font color='green'>$c</font>";	
					}
					
					
					
					?> 
					
					
					
					<?php
			
					include_once('../config/db.php');

					$database = new Connection();
					$db = $database->open();
					try{	
						$sql = 'SELECT * FROM mainlogin WHERE id=1 ';
						foreach ($db->query($sql) as $row) {
							?>
						
								
								
							<?php 
						}
					}
					catch(PDOException $e){
						echo "Hubo un problema en la conexión: " . $e->getMessage();
					}

					$database->close();

						?>
					
					
					
					</h1>
					
					<h5>
					<strong>Tu último acceso es:</strong>
					<div id="date" style="margin-left:140px; margin-top:-15px;"></div>
					 
					</h5>
					
											<?php

				$user_agent = $_SERVER['HTTP_USER_AGENT'];

				function getBrowser($user_agent){

				if(strpos($user_agent, 'MSIE') !== FALSE)
				   return 'Internet explorer';
				 elseif(strpos($user_agent, 'Edge') !== FALSE) //Microsoft Edge
				   return 'Microsoft Edge';
				 elseif(strpos($user_agent, 'Trident') !== FALSE) //IE 11
					return 'Internet explorer';
				 elseif(strpos($user_agent, 'Opera Mini') !== FALSE)
				   return "Opera Mini";
				 elseif(strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR') !== FALSE)
				   return "Opera";
				 elseif(strpos($user_agent, 'Firefox') !== FALSE)
				   return 'Mozilla Firefox';
				 elseif(strpos($user_agent, 'Chrome') !== FALSE)
				   return 'Google Chrome';
				 elseif(strpos($user_agent, 'Safari') !== FALSE)
				   return "Safari";
				 else
				   return 'No hemos podido detectar su navegador';


				}


				$navegador = getBrowser($user_agent);
				 
				echo "<strong>Navegador</strong>: ".$navegador;

						?>
					
				
            </div>
        </div>
		<tr>
								<td class="inner title "width="1170" bgcolor="#ffffff"  >
									<div style="font-size:60px;line-height:42px;color:#115213;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;padding-bottom: 20px;">
									Dominios</div>
								</td>
							</tr>
			<!-- End of banner image --><!-- Start of text with picture on the left -->			
			<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;background-color:#fff" width="1170" cellspacing="0" cellpadding="0" border="0" bgcolor="#fff" align="center">
				<tbody>
				<tr>
					<td class="tables-container" style="border: 1px solid gray;">
						<!--[if mso]><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-collapse:collapse; max-width:100%;"><tr><td><![endif]-->
						<table class="col-half" style="border-collapse:collapse; mso-table-lspace:0; mso-table-rspace:0; border-width:0; border-spacing:0;background-color: #fff;" width="50%" cellspacing="0" cellpadding="0" border="0">
							<tbody><tr>
								<td class="spacing1" style=" padding:10px 30px 10px 30px;text-align: center; font-family:'Roboto', Helvetica, Arial, sans-serif; font-weight:300; font-size:18px; line-height:150%; color:#666666; text-align: center;">
									<!-- Button trigger modal -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;    border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/imaginary.png-98547d-128c.png">
									<a href="../mensajes/mostrar_dominio.php"style="padding-right: 250px; color: black;">Números complejos</a>
									<br>
									</a><br>
									<!-- FIN DE LA INSTRUCCION -->
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/similarity.png-003d79-128c.png">
									<a href="../mensajes/mostrar_dominio1.php"style="padding-right: 210px; color: black;">Funciones Compuestas</a><br><br>

									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/precalculus.png-f89238-128c.png">
									<a href="../mensajes/mostrar_dominio2.php"style="padding-right: 290px; color: black;">Trigonometría</a>
									<br><br>
									<a href="../mensajes/mostrar_dominio.php"style="padding-right: 290px; color: black;">Matrices</a>
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/precalculus.png-f89238-128c.png">
									<br><br>	<a href="../mensajes/mostrar_dominio.php"style="padding-right: 290px; color: black;">Series</a>
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/precalculus.png-f89238-128c.png">
									<br><br>	<a href="../mensajes/mostrar_dominio.php"style="padding-right: 250px; color: black;">Secciones cónicas</a>
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/precalculus.png-f89238-128c.png">

									<br><br>
									<img  style="width: 1em; height:1em;margin:4px auto; display:block; float:left;border-radius: 16px !important;" src="https://cdn.kastatic.org/genfiles/topic-icons/icons/precalculus.png-f89238-128c.png">
										<a href="../mensajes/mostrar_dominio.php"style="padding-right: 290px; color: black;">Probabilidad </a>
									<!-- Modal 1.0 -->
									<div id="exampleModalCenter2" class="modal fade" style="padding:130px 0px 0px 160px !important;"  tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" >
									<div class="modal-dialog modal-dialog-centered" role="document">
										<div class="modal-content " style="width: 800px;">
										<div class="modal-header">
											<h5 class="modal-title" style="font-size:35px;line-height:42px;color:#022601;font-family:'Libre Bodoni','times new roman','serif'!important;font-style:italic!important;font-weight:400!important;text-align:center;" id="exampleModalLongTitle"> Introducción a los números imaginarios</h5>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<!-- End of banner image --><!-- Start of short intro text -->			
			<table class="row" style="border-collapse:collapse; text-align:left; border-spacing:0; font-family: 'Roboto', Helvetica, Arial, sans-serif; font-size:18px; line-height:150%; color:#666666; margin:0px auto; max-width:100%; border-bottom:0px solid #eeeeee;" width="600" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
				<tbody>
				<tr>
					<td class="inner title" style="padding:30px 30px 5px 30px;">
						<div style="
						color: #21242c;
    					font-size: 19px;
   						 line-height: 30px;
    					margin-bottom: 32px;
    					margin-top: 0;
						font-family:'Libre Bodoni','times new roman','serif'!important;font-weight:400!important;text-align:left">
							En tu estudio de las matemáticas, puedes haber observado que algunas <br>ecuaciones cuadráticas no tienen solución en los números reales.<br><br>
							Por ejemplo, por más que lo intentes, nunca encontrarás un número real que sea solución de la ecuación x^2=-1. Esto se debe a que es imposible elevar un 
							número real al cuadrado y ¡obtener un número negativo!<br><br>

							Sin embargo, sí existe una solución de la ecuanción x^2=-1  en un nuevo sistema de números, que se llama el sistema de números complejos.<br><br>
							<b>La unidad imaginaria </b><br>
							La columna vertebral de este nuevo sistema de números es la unidad imaginaria, o sea el número i.<br>
							Las siguientes propiedades son verdaderas para el número i:<br><br>
							<img  style=" float:left;" src="https://i.ibb.co/NmHqb7J/Captura1.png">
						
						
						</div>
					</td>
				</tr>
			</tbody></table>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
											<!-- <button type="button" class="btn btn-primary">Save changes</button> -->
										</div>
										</div>
									</div>
									</div>
							<!-- FIN DE LA INSTRUCCION -->
								</td>
								<!-- FIN DE LA COLUMNA -->
								
							</tr>
							<tr>
					<!-- <td class="spacing2" style="text-align: center;"  >
						<span class="bottom_yellow" href="#" >explore more>></span>
					</td> -->
				</tr>
						</tbody></table>
						<!--[if mso]></td></tr></table><![endif]-->
					</td>
				</tr>
			</tbody></table><br><br>
	<!-- End of logo with issue number --><!-- Start of banner image -->
		><tr>
					<td style="text-align:center;">
						<img class="banner" alt="image" src="http://www.webquestcreator2.com/majwq/files/files_user/49784/infografia-4.jpg" style="display: block; width: 100%;" width="600" vspace="0" hspace="0" border="0">
					</td>

      
	 <script src="../../assets/js/reloj.js"></script> 
	 	<script>
$(window).on('load', function () {
      setTimeout(function () {
    $(".loading").css({visibility:"hidden",opacity:"0"})
  }, 500);
     
});
</script>
</body>
</html>
