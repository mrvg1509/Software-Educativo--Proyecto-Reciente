baseDePreguntas = [
    {
      pregunta: `Una matriz es un conjunto de letras colocados en m (filas) y n (columnas)`,
      imagen: `https://t1.up.ltmcdn.com/es/posts/9/4/7/soluciones_749_6_600.jpg`,
      respuesta: `Si`,
      distractores: [`No`, `Talvez`, `Ninguna de las anteriores`],
      ayuda: `Es un arreglo que consta de 2 partes`,
      ayudaImg: `https://economipedia.com/wp-content/uploads/Captura-de-pantalla-2022-01-08-a-les-9.08.16-1024x390.png`,
    },
    {
      pregunta: `¿Cuánto es 2+2?`,
      respuesta: `4`,
      distractores: [`3`, `2`, `1`],
      ayuda: `es lo mismo que 2*2`,
      ayudaImg: `https://i.ibb.co/k1WgGW2/descarga.jpg`,
    },
    {
      pregunta: `¿Qué tipo de número es 90.6i?`,
      respuesta: `Imaginarios`,
      distractores: [`Real`, `Complejo`, `Fraccionario`],
    }
  ];