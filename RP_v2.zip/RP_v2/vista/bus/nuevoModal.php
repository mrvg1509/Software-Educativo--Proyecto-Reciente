<!-- Agregar Nuevos Registros -->
<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Listado de docentes</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			
		
			
            </div>

        </div>
    </div>
</div>
</div>